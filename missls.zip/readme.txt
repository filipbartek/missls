missls


Tactical nuclear warfare party minigame

for up to 3 cannon masters.


Controls:

F2: Restart game and resize the planet

Blue cannon: arrow keys
Orange cannon: WSAD
Fuchsia cannon: IKJL

Press Up to join the game.

Left and right: Aim
Up: Fire missile
Down: Detonate missile


Author: Filip B�rtek
GitHub page: https://github.com/filipbartek/missls